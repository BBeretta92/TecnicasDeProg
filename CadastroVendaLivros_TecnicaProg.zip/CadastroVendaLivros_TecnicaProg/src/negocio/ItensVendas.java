package negocio;

public class ItensVendas {

	private int codvendas;
	private int codlivro;
	private int quantidade;
	
	public ItensVendas(int codvendas, int codlivro, int quantidade) {
		this.codvendas = codvendas;
		this.codlivro = codlivro;
		this.quantidade = quantidade;
	}
	public int getCodvendas() {
		return codvendas;
	}
	public void setCodvendas(int codvendas) {
		this.codvendas = codvendas;
	}
	public int getCodlivro() {
		return codlivro;
	}
	public void setCodlivro(int codlivro) {
		this.codlivro = codlivro;
	}
	public int getQuantidade() {
		return quantidade;
	}
	public void setQuantidade(int quantidade) {
		this.quantidade = quantidade;
	}
	
	
}
