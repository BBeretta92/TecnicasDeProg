package negocio;

import java.sql.Date;

public class Vendas {

    private int codigo;
    private String nomeCliente;
    private String CPFCliente;
    private String CNPJCliente;
    private Date data;

    public Vendas(int codigo, String nomeCliente, String CPFCliente, String CNPJCliente, Date data) {
        this.codigo = codigo;
        this.nomeCliente = nomeCliente;
        this.CPFCliente = CPFCliente;
        this.CNPJCliente = CNPJCliente;
        this.CNPJCliente = CNPJCliente;
        this.data = data;
    }

    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public String getNomeCliente() {
        return nomeCliente;
    }

    public void setNomeCliente(String nomeCliente) {
        this.nomeCliente = nomeCliente;
    }

    public String getCPFCliente() {
        return CPFCliente;
    }

    public void setCPFCliente(String cPFCliente) {
        CPFCliente = cPFCliente;
    }

    public String getCNPJCliente() {
        return CNPJCliente;
    }

    public void setCNPJCliente(String cNPJCliente) {
        CNPJCliente = cNPJCliente;
    }

    public Date getData() {
        return data;
    }

    public void setData(Date data) {
        this.data = data;
    }

}
