package persistencia;

public class DAOVendasException extends Exception {

	public DAOVendasException(){
		super();
	}
	public DAOVendasException(String mensagem) {
		super(mensagem);
	}
	public DAOVendasException(String mensagem, Throwable causa) {
		super(mensagem, causa);
	}
}