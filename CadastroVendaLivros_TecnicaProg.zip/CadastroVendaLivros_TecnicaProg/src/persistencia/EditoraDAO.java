package persistencia;

import persistencia.DAOEditoraException;
import java.util.List;
import negocio.Editora;

public interface EditoraDAO {
	List<Editora> buscarTodos() throws DAOEditoraException;
	Editora buscarPorCodigo(int codigo) throws DAOEditoraException;
	void inserir(Editora editora) throws DAOEditoraException;
	void alterar(Editora editora) throws DAOEditoraException;
}
