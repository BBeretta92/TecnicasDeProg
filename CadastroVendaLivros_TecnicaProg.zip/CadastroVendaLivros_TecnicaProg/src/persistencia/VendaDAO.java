package persistencia;

import java.util.List;

import negocio.ItensVendas;
import negocio.Vendas;
import persistencia.DAOVendasException;

public interface VendaDAO {

    List<Vendas> buscarTodos() throws DAOVendasException;

    Vendas buscarPorCodigo(int venda) throws DAOVendasException;

    void alterar(Vendas venda) throws DAOVendasException;

    void inserir(Vendas venda, List<ItensVendas> itensVendas) throws DAOVendasException;

    List<String> buscarQtdLivrosAutorVendido(int codAutor) throws DAOVendasException;

    List<ItensVendas> buscarTodosItens() throws DAOVendasException;

}
