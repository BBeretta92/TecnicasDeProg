package persistencia;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import negocio.Autor;
import negocio.ItensVendas;
import negocio.Livro;
import negocio.Vendas;

public class VendasDAOderby implements VendaDAO {

    @Override
    public List<Vendas> buscarTodos() throws DAOVendasException {
        List<Vendas> listVendas = new ArrayList<>();

        Connection conexao;

        Statement comandoVendas;
        String sqlVendas = "select * from Vendas";
        ResultSet resultadoVendas;
        try {
            conexao = InicializadorBancoDados.conectarBd();
            comandoVendas = conexao.createStatement();
            resultadoVendas = comandoVendas.executeQuery(sqlVendas);
            // Para cada linha da tabela livros
            while (resultadoVendas.next()) {
                Vendas venda = new Vendas(resultadoVendas.getInt("CODIGO"), resultadoVendas.getString("NOMECLIENTE"), resultadoVendas.getString("CPFCLIENTE"), resultadoVendas.getString("CNPJCLIENTE"), resultadoVendas.getDate("DATA"));
                listVendas.add(venda);
            }
            comandoVendas.close();
            conexao.close();
            return listVendas;
        } catch (Exception e) {
            throw new DAOVendasException("Falha na busca: " + e.getMessage(), e);
        }
    }

    @Override
    public List<ItensVendas> buscarTodosItens() throws DAOVendasException {
        List<ItensVendas> listVendasItens = new ArrayList<>();

        Connection conexao;

        Statement comandoVendas;
        String sqlVendas = "select * from ITENSVENDA";
        ResultSet resultadoVendas;
        try {
            conexao = InicializadorBancoDados.conectarBd();
            comandoVendas = conexao.createStatement();
            resultadoVendas = comandoVendas.executeQuery(sqlVendas);
            // Para cada linha da tabela livros
            while (resultadoVendas.next()) {
                ItensVendas vendaItem = new ItensVendas(resultadoVendas.getInt("CODLIVRO"), resultadoVendas.getInt("CODVENDA"), resultadoVendas.getInt("QUANTIDADE"));
                listVendasItens.add(vendaItem);
            }
            comandoVendas.close();
            conexao.close();
            return listVendasItens;
        } catch (Exception e) {
            throw new DAOVendasException("Falha na busca: " + e.getMessage(), e);
        }
    }

    @Override
    public Vendas buscarPorCodigo(int codigo) throws DAOVendasException {
        Vendas venda = null;
        Connection conexao;

        PreparedStatement comandoVendas;
        String sqlVenda = "select * from Vendas where codigo = ?";
        ResultSet resultadoVendas;
        try {
            conexao = InicializadorBancoDados.conectarBd();
            comandoVendas = conexao.prepareStatement(sqlVenda);
            comandoVendas.setInt(1, codigo);
            resultadoVendas = comandoVendas.executeQuery();

            venda = new Vendas(resultadoVendas.getInt("CODIGO"), resultadoVendas.getString("NOMECLIENTE"), resultadoVendas.getString("CPFCLIENTE"), resultadoVendas.getString("CNPJCLIENTE"), resultadoVendas.getDate("DATA"));

            comandoVendas.close();
            conexao.close();
            return venda;
        } catch (Exception e) {
            throw new DAOVendasException("Falha na busca: " + e.getMessage(), e);
        }
    }

    @Override
    public void inserir(Vendas venda, List<ItensVendas> itensVendas) throws DAOVendasException {

        Connection conexao;
        PreparedStatement comandoVendas, comandoItensVendas;
        String sqlVendas = "insert into Vendas(codigo,nomecliente,cpfcliente,cnpjcliente,data) values(?,?,?,?,?)";
        String sqlItensVendas = "insert into ItensVenda(codvenda,codlivro, quantidade) values(?,?,?)";
        int resultado = 0;

        try {

            conexao = InicializadorBancoDados.conectarBd();

            // Insere as vendas
            comandoVendas = conexao.prepareStatement(sqlVendas);
            comandoVendas.setInt(1, venda.getCodigo());
            comandoVendas.setString(2, venda.getNomeCliente());
            comandoVendas.setString(3, venda.getCPFCliente());
            comandoVendas.setString(4, venda.getCNPJCliente());
            comandoVendas.setDate(5, venda.getData());
            resultado = comandoVendas.executeUpdate();
            comandoVendas.close();

            // Insere as vendas-itens
            comandoItensVendas = conexao.prepareStatement(sqlItensVendas);
            for (ItensVendas itensVenda : itensVendas) {
                comandoItensVendas.setInt(1, itensVenda.getCodvendas());
                comandoItensVendas.setInt(2, itensVenda.getCodlivro());
                comandoItensVendas.setInt(3, itensVenda.getQuantidade());
                resultado += comandoItensVendas.executeUpdate();
            }
            comandoItensVendas.close();
            conexao.close();
        } catch (Exception e) {
            throw new DAOVendasException("Falha na insercao", e);
        }
    }

    //USADO L�GICA DTO MAS N�O CRIANDO UM NOVO OBJETO PARA TAL E UTILIZANDO LIST<STRING> PARA EXIBIR TAIS MENSAGENS;
    @Override
    public List<String> buscarQtdLivrosAutorVendido(int codAutor) throws DAOVendasException {
        int qtd = 0;
        List<String> livros_qtd = new ArrayList<>();

        Connection conexao;

        PreparedStatement comandoQTD;
        String sqlqtdLivrosdoAutor = "SELECT livros.titulo, SUM(itensvenda.quantidade) as qtd FROM livros,livrosAutores,itensvenda WHERE livros.codigo = livrosAutores.codlivro AND livrosAutores.codlivro = itensVenda.codlivro AND livrosAutores.codautor = ? GROUP BY livros.titulo";

        ResultSet resultadoqtd;
        try {
            conexao = InicializadorBancoDados.conectarBd();
            comandoQTD = conexao.prepareStatement(sqlqtdLivrosdoAutor);
            comandoQTD.setInt(1, codAutor);
            resultadoqtd = comandoQTD.executeQuery();
            // Para cada linha da tabela livros
            while (resultadoqtd.next()) {
                livros_qtd.add(resultadoqtd.getString("titulo") + ": " + String.valueOf(resultadoqtd.getInt("qtd")));
            }
            comandoQTD.close();
            conexao.close();
            return livros_qtd;
        } catch (Exception e) {
            throw new DAOVendasException("Falha na busca: " + e.getMessage(), e);
        }
    }

    @Override
    public void alterar(Vendas venda) throws DAOVendasException {
        Connection conexao = null;
        PreparedStatement comando;
        PreparedStatement cmdApagar;
        PreparedStatement cmdLivrosAutores;

        String sql = "update Vendas set nomeCliente=?, CPFCliente=?, CNPJCliente=?, where codigo = ?";

        int resultado = 0;
        try {
            conexao = InicializadorBancoDados.conectarBd();
            comando = conexao.prepareStatement(sql);
            comando.setString(1, venda.getNomeCliente());
            comando.setString(2, venda.getCPFCliente());
            comando.setString(3, venda.getCNPJCliente());
            comando.setInt(4, venda.getCodigo());
            resultado = comando.executeUpdate();
            comando.close();

        } catch (Exception e) {
            throw new DAOVendasException("Falha na alteracao: " + e.getMessage(), e);
        }
        if (resultado == 0) {
            throw new DAOVendasException("Falha na alteracao");
        }
    }

}
